<?php
include 'includes/header.php'
?>

<section>
	<div class="mixing">
		<div class="container">
			<img src="img/mix.jpg" alt="" />
		</div>
		<div class="container">
			<h3>
				<strong>Mixing & Mastering</strong>
			</h3>
			<p>
				<strong>
					$50.00 – $150.00 <br />
					BASIC
				</strong>
				<br />
			</p>
			<ul>
				<li>3 REVISIONS</li>
				<li>5 AUDIO TRACKS (MIXED & MASTERED)</li>
			</ul>
			<p>
				<strong>
					ADVANCED
				</strong>
				<br />
			</p>
			<ul>
				<li>5 REVISIONS</li>
				<li>10 AUDIO TRACKS (MIXED & MASTERED)</li>
			</ul>
			<p>
				<strong>
					EXPERT
				</strong>
				<br />
			</p>
			<ul>
				<li>UNLIMITED REVISIONS</li>
				<li>UNLIMITED TRACKS (MIXED & MASTERED)</li>
			</ul>
		</div>
	</div>
</section>

<?php
include 'includes/footer.php'
?>